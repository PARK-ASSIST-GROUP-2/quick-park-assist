package com.quick_park_assist.controller;

import java.util.List;

import com.quick_park_assist.service.IViewBookingByMobileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.quick_park_assist.entity.BookingSpot;

@Controller
@RequestMapping("/viewBookingByMobile")
public class ViewBookingByMobileController {

    @Autowired
    private IViewBookingByMobileService viewByMobileNumberService;

    @GetMapping("/")
    public String showBookingForm(Model model) {
        System.out.println("Working inside modify form controller");
        model.addAttribute("bookingSpot", new BookingSpot());
        return "ViewBookingByMobile";
    }

    @PostMapping("/viewbooking-mobile")
    public String getBookingDetails(@RequestParam String mobileNumber, Model model) {
        List<BookingSpot> bookings = viewByMobileNumberService.getBookingsByMobileNumber(mobileNumber);
        model.addAttribute("bookings", bookings);
        return "ViewBookingByMobile";
    }
}
