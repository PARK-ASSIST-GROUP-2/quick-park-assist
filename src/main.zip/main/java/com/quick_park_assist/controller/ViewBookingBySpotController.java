package com.quick_park_assist.controller;

import com.quick_park_assist.entity.BookingSpot;
import com.quick_park_assist.service.IViewBookingBySpotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/viewBookingBySpot")
public class ViewBookingBySpotController {

    @Autowired
    private IViewBookingBySpotService viewBySpotService;

    @GetMapping("/")
    public String showSpotForm(Model model) {
        model.addAttribute("spotID", "");
        model.addAttribute("bookings", null);
        return "ViewBookingBySpot";
    }

    @PostMapping("/viewbooking-spot")
    public String getBookingDetails(@RequestParam("spotID") String spotID, Model model) {
        List<BookingSpot> bookings = viewBySpotService.getBookingsBySpotID(spotID);
        model.addAttribute("spotID", spotID);
        model.addAttribute("bookings", bookings);
        return "ViewBookingBySpot";
    }
}

