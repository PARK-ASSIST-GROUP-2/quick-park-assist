package com.quick_park_assist.repository;

import com.quick_park_assist.entity.BookingSpot;
import java.util.Optional;

import com.quick_park_assist.enums.BookingSpotStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingSpotRepository extends JpaRepository<BookingSpot, Long> {
    Optional<BookingSpot> findByBookingIdAndMobileNumber(Long bookingId, String mobileNumber);
    List<BookingSpot> findByMobileNumber(String mobileNumber);
    // used in cancel-booking
    List<BookingSpot> findByMobileNumberAndBookingSpotStatus(String mobileNumber, BookingSpotStatus bookingSpotStatus);
    List<BookingSpot> findBySpotID(String spotID);
}