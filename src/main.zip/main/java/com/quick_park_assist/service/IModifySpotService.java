package com.quick_park_assist.service;

import com.quick_park_assist.entity.BookingSpot;

import java.util.Date;
import java.util.List;

public interface IModifySpotService {
    boolean updateSpotDetails(Long BookingId, Date startTime, Double duration);
    List<BookingSpot> getConfirmedBookings(String mobileNumber);
}
